#include<iostream>
#include<string>
#include"swap.h"

using namespace std;

int main()
{

    string user;
    // cout<<"hello world"<<endl;
    // int a=10,b=20;
    // cout<<"Before:"<<endl;
    // cout<<"a="<<a<<endl;
    // cout<<"b="<<b<<endl;
    // cout<<"After:"<<endl;
    // swap(a,b);
    // cout<<"a="<<a<<endl;
    // cout<<"b="<<b<<endl;
    cin >> user;
    cout<<user<<endl;
    system("pause");

    return 0;


}