#include<iostream>
int main(){
    printf("sdf");
}